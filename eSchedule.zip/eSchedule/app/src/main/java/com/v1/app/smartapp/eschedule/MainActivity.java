package com.v1.app.smartapp.eschedule;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.view.MenuInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.github.lzyzsd.circleprogress.DonutProgress;

import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    CardView cardView = null;
    NavigationView navigationView;
    Toolbar toolbar;
    //private DonutProgress timeProgressBar;
    //private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set Fragment Initially for my Main Activity
        HomeTransition fragment = new HomeTransition();
        android.support.v4.app.FragmentTransaction fragmentTransaction =
                getSupportFragmentManager().beginTransaction();

        //fragment container
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.commit();

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //HomeCard View2
        cardView = (CardView) findViewById(R.id.view);
        //create an instance of timeProgress
        //timeProgressBar = (DonutProgress) findViewById(R.id.timeLeft);

        //create Timer
        //time remaining progress Bar animation
        //timer = new Timer();
        /*timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //setup the Timer Schedule
                        timeProgressBar.setProgress(timeProgressBar.getProgress() + 1);
                    }
                });
            }
        }, 1000, 100);*/


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //timer.cancel();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int res_id = item.getItemId();

        //settingsOption
        if (res_id == R.id.action_settings) {

            Toast.makeText(getApplicationContext(), "Settings Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //searchOption
        if (res_id == R.id.action_search) {

            Toast.makeText(getApplicationContext(), "Search Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //dashboardOption
        if (res_id == R.id.action_dashboard) {

            Toast.makeText(getApplicationContext(), "Dashboard Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //AboutUsOption
        if (res_id == R.id.about_us) {

            Toast.makeText(getApplicationContext(), "About Us Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            //set Fragment Initially
            HomeTransition fragment = new HomeTransition();
            android.support.v4.app.FragmentTransaction fragmentTransaction =
                    getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container, fragment);
            fragmentTransaction.commit();

            // Handle the camera action
        } else if (id == R.id.nav_schedule) {
            startActivity(new Intent(this, Schedule.class));

        } else if (id == R.id.nav_task) {
            startActivity(new Intent(this, Task.class));

        } else if (id == R.id.nav_settings) {
            startActivity(new Intent(this, Settings.class));

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
