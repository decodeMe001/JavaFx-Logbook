package com.v1.app.smartapp.eschedule;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Button;
import android.widget.DatePicker;


import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 */
public class Scope extends Fragment {

    protected static Button txtDate, txtDateEnds, txtTimeIn, txtTimeOut, txtDisable;

    ScopeListener activityCommander;

    public interface ScopeListener {
        public void alarmHouse();

        public void disableAlarm();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            activityCommander = (ScopeListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_scope, container, false);

        txtDate = (Button) view.findViewById(R.id.btn_termBegins);
        txtDateEnds = (Button) view.findViewById(R.id.btn_termEnds);
        txtTimeIn = (Button) view.findViewById(R.id.time_in);
        txtTimeOut = (Button) view.findViewById(R.id.time_out);
        txtDisable = (Button) view.findViewById(R.id.disable);
        assert txtDate != null;
        assert txtDateEnds != null;
        assert txtTimeIn != null;
        assert txtTimeOut != null;
        assert txtDisable != null;
        termBegins();
        termEnds();
        periodTimeIn();
        periodTimeOut();
        disableAlert();
        activityCommander.alarmHouse();

        return view;

    }


    public void termBegins() {
        txtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SectionEndsDate mDatePicker = new SectionEndsDate();
                mDatePicker.show(getFragmentManager(), "Select date");
            }
        });
    }

    public void termEnds() {
        txtDateEnds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SectionBeginsDate mDatePicker = new SectionBeginsDate();
                mDatePicker.show(getFragmentManager(), "Select date");
            }
        });
    }

    public static class SectionEndsDate extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar cal = Calendar.getInstance();
            int year_x = cal.get(Calendar.YEAR);
            int month_x = cal.get(Calendar.MONTH);
            int day_x = cal.get(Calendar.DAY_OF_MONTH);

            return new DatePickerDialog(getActivity(), this, year_x, month_x, day_x);
        }

        public void onDateSet(DatePicker view, int year_x, int month_x, int day_x) {
            txtDate.setText("Section Begins: " + String.valueOf(day_x) + " - " + String.valueOf(month_x + 1) + " - " + String.valueOf(year_x));
        }
    }

    public static class SectionBeginsDate extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar cal = Calendar.getInstance();
            int year_x = cal.get(Calendar.YEAR);
            int month_x = cal.get(Calendar.MONTH);
            int day_x = cal.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year_x, month_x, day_x);
        }

        public void onDateSet(DatePicker view, int year_x, int month_x, int day_x) {
            txtDateEnds.setText("Section Ends: " + String.valueOf(day_x) + " / " + String.valueOf(month_x + 1) + " / " + String.valueOf(year_x));
        }
    }

    public void periodTimeIn() {
        txtTimeIn.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        TimeInPicker mTimePicker = new TimeInPicker();
                        mTimePicker.show(getFragmentManager(), "Select time");
                        activityCommander.alarmHouse();
                    }
                });
    }

    public void periodTimeOut() {
        txtTimeOut.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TimeOutPicker mTimePicker = new TimeOutPicker();
                        mTimePicker.show(getFragmentManager(), "Select time");
                    }
                });
    }


    public static class TimeInPicker extends DialogFragment implements TimePickerDialog.OnTimeSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);
            return new TimePickerDialog(getActivity(), this, hour, minute, DateFormat.is24HourFormat(getActivity()));
        }

        @Override
        public void onTimeSet(android.widget.TimePicker view, int hour, int minute) {

            txtTimeIn.setText(String.valueOf((hour == 0 || hour == 12) ? 12 : hour % 12) + " : "
                    + String.valueOf((minute < 10) ? "0" + minute : minute) + " " + (hour < 12 ? "AM" : "PM"));


        }
    }


    public static class TimeOutPicker extends DialogFragment implements TimePickerDialog.OnTimeSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);
            return new TimePickerDialog(getActivity(), this, hour, minute, DateFormat.is24HourFormat(getActivity()));
        }

        @Override
        public void onTimeSet(android.widget.TimePicker view, int hour, int minute) {

            txtTimeOut.setText(String.valueOf((hour == 0 || hour == 12) ? 12 : hour % 12) + " : "
                    + String.valueOf((minute < 10) ? "0" + minute : minute) + " " + (hour < 12 ? "AM" : "PM"));

        }
    }

    private void disableAlert() {

    }
    //activityCommander.disableAlarm();


}

