package com.v1.app.smartapp.eschedule;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by Dada abiola on 6/10/2016.
 */
public class Notification_receiver extends BroadcastReceiver{

    @Override
    public void onReceive(Context context, Intent intent) {

        Intent service_intent = new Intent(context, RingtonePlayingService.class);
        context.startService(service_intent);
    }
}
