package com.v1.app.smartapp.eschedule;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Calendar;


public class Schedule extends AppCompatActivity implements Scope.ScopeListener {

    CardView cardView = null;
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    ViewPagerAdapter viewPagerAdapter;
    Context context;

    //create an array input for the tabs
    private int[] tabIcons = {
            R.drawable.ic_timeline_icon,
            R.drawable.ic_schedule_icon,
            R.drawable.ic_explore_icon
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        //initilize this variable
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        this.context = this;
        cardView = (CardView) findViewById(R.id.cv);

        //tab Layout Setup with Adapter
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new Profile(), "PROFILE");
        viewPagerAdapter.addFragment(new Scope(), "SCOPE");
        viewPagerAdapter.addFragment(new Explore(), "EXPLORE");
        viewPager.setAdapter(viewPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        setupTabIcons();

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    //Alarm method to trigger alarm at time picked
    public void alarmHouse() {
        Intent intent = new Intent(this.context, Notification_receiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 100, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm_manager = (AlarmManager) getSystemService(ALARM_SERVICE);

        final Calendar c = Calendar.getInstance();
        Calendar now = Calendar.getInstance();
        c.get(Calendar.HOUR_OF_DAY);
        c.get(Calendar.MINUTE);

        //check whether the time is earlier than current time. If so, set it to tomorrow. Otherwise, all alarms for earlier time will fire
        if(c.before(now)){
            c.add(Calendar.DATE, 1);
        }

        alarm_manager.setRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);


    }
    //disable Alarm
    public void disableAlarm() {
        final Calendar c = Calendar.getInstance();
        Intent intent = new Intent(getApplicationContext(), Notification_receiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 100, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm_manager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarm_manager.cancel(pendingIntent);
    }

    private void setupTabIcons() {
        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
        tabLayout.getTabAt(2).setIcon(tabIcons[2]);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int res_id = item.getItemId();

        //settingsOption
        if (res_id == R.id.action_settings) {

            Toast.makeText(getApplicationContext(), "Settings Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //searchOption
        if (res_id == R.id.action_search) {

            Toast.makeText(getApplicationContext(), "Search Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //dashboardOption
        if (res_id == R.id.action_dashboard) {

            Toast.makeText(getApplicationContext(), "Dashboard Clicked", Toast.LENGTH_LONG).show();
            return true;
        }

        //AboutUsOption
        if (res_id == R.id.about_us) {

            Toast.makeText(getApplicationContext(), "About Us Clicked", Toast.LENGTH_LONG).show();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }


}
