package com.v1.app.smartapp.eschedule;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Dada abiola on 6/12/2016.
 */
public class RingtonePlayingService extends Service {

    MediaPlayer media_song;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        Log.i("Local Service", "Received start id" + startId + ":" + intent);

        //creates an instance of MediaPlayer
        media_song = MediaPlayer.create(this, R.raw.alarmclock);
        media_song.start();


        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy(){

        Toast.makeText(this, "Service Destroy", Toast.LENGTH_SHORT).show();
    }
}
